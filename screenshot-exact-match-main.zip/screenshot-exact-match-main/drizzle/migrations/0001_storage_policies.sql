
CREATE POLICY "Upload own food photos" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'food-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "View food photos" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'food-photos' AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_verified_recipient_member(auth.uid())
    OR public.has_any_role(auth.uid(), ARRAY['super_admin','volunteer']::public.app_role[])));
CREATE POLICY "Upload own org documents" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'org-documents' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "View own org documents" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'org-documents' AND ((storage.foldername(name))[1] = auth.uid()::text OR public.has_role(auth.uid(),'super_admin')));
