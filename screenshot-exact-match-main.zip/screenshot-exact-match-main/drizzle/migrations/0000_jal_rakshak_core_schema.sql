
-- ===== ENUMS =====
CREATE TYPE public.app_role AS ENUM ('super_admin','municipal_authority','disaster_officer','iot_operator','ngo_admin','food_donor','recipient_org','volunteer','public_user');
CREATE TYPE public.org_type AS ENUM ('ngo','food_bank','night_shelter','orphanage','old_age_home','community_kitchen','hospital_welfare','outreach','catering','hotel','restaurant','banquet_hall','religious','event_organizer','corporate','municipal','other');
CREATE TYPE public.verification_status AS ENUM ('pending','verified','rejected');
CREATE TYPE public.member_status AS ENUM ('pending','approved','rejected');
CREATE TYPE public.donation_status AS ENUM ('posted','safety_review','verified','matched','accepted','pickup_assigned','collected','delivered','completed','cancelled','rejected','expired');
CREATE TYPE public.food_category AS ENUM ('cooked_meal','rice_grains','bread_roti','curry_dal','sweets_dessert','fruits_vegetables','packaged','beverages','other');
CREATE TYPE public.storage_condition AS ENUM ('hot_held','refrigerated','room_temperature','frozen');
CREATE TYPE public.packaging_condition AS ENUM ('sealed','covered_containers','open_trays','damaged');
CREATE TYPE public.match_status AS ENUM ('proposed','accepted','rejected','pickup_assigned','collected','delivered','completed','cancelled');
CREATE TYPE public.delivery_status AS ENUM ('assigned','picked_up','delivered','cancelled');
CREATE TYPE public.risk_level AS ENUM ('normal','watch','alert','severe','emergency');
CREATE TYPE public.alert_status AS ENUM ('active','resolved');
CREATE TYPE public.device_type AS ENUM ('water_level','rain_gauge','soil_moisture','weather_station','gateway','gps');

-- ===== updated_at helper =====
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ===== PROFILES =====
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text,
  preferred_language text NOT NULL DEFAULT 'en',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ===== USER ROLES =====
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
CREATE OR REPLACE FUNCTION public.has_any_role(_user_id uuid, _roles public.app_role[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = ANY(_roles))
$$;

CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Super admins grant roles" ON public.user_roles FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Super admins revoke roles" ON public.user_roles FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'super_admin'));

CREATE POLICY "Read own profile or admin" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "Update own profile" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- ===== ORGANIZATIONS =====
CREATE TABLE public.organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  org_type public.org_type NOT NULL,
  is_recipient boolean NOT NULL DEFAULT true,
  registration_number text,
  contact_email text,
  contact_phone text,
  address text NOT NULL DEFAULT '',
  latitude double precision,
  longitude double precision,
  receiving_capacity_kg numeric NOT NULL DEFAULT 0 CHECK (receiving_capacity_kg >= 0),
  current_load_kg numeric NOT NULL DEFAULT 0 CHECK (current_load_kg >= 0),
  vegetarian_only boolean NOT NULL DEFAULT false,
  allergen_exclusions text[] NOT NULL DEFAULT '{}',
  food_requirements text,
  operating_hours text,
  pickup_preference text,
  verification_status public.verification_status NOT NULL DEFAULT 'pending',
  verification_notes text,
  verified_by uuid,
  verified_at timestamptz,
  created_by uuid NOT NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX organizations_verified_idx ON public.organizations (verification_status, is_recipient);
GRANT SELECT, INSERT, UPDATE ON public.organizations TO authenticated;
GRANT ALL ON public.organizations TO service_role;
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER organizations_updated BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.organization_members (
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  member_role text NOT NULL DEFAULT 'member' CHECK (member_role IN ('admin','member','volunteer')),
  status public.member_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (organization_id, user_id)
);
CREATE INDEX org_members_user_idx ON public.organization_members (user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organization_members TO authenticated;
GRANT ALL ON public.organization_members TO service_role;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_org_member(_user_id uuid, _org uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members WHERE user_id=_user_id AND organization_id=_org AND status='approved')
$$;
CREATE OR REPLACE FUNCTION public.is_org_admin(_user_id uuid, _org uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members WHERE user_id=_user_id AND organization_id=_org AND status='approved' AND member_role='admin')
$$;
CREATE OR REPLACE FUNCTION public.is_verified_recipient_member(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members m JOIN public.organizations o ON o.id=m.organization_id
    WHERE m.user_id=_user_id AND m.status='approved' AND o.verification_status='verified' AND o.is_recipient)
$$;

CREATE POLICY "Members read their memberships" ON public.organization_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_org_admin(auth.uid(), organization_id) OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Request to join" ON public.organization_members FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND status = 'pending' AND member_role <> 'admin');
CREATE POLICY "Org admins manage members" ON public.organization_members FOR UPDATE TO authenticated
  USING (public.is_org_admin(auth.uid(), organization_id) OR public.has_role(auth.uid(),'super_admin'))
  WITH CHECK (public.is_org_admin(auth.uid(), organization_id) OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Leave or remove members" ON public.organization_members FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR public.is_org_admin(auth.uid(), organization_id) OR public.has_role(auth.uid(),'super_admin'));

CREATE OR REPLACE FUNCTION public.organizations_guard() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.has_role(auth.uid(),'super_admin') THEN
    IF TG_OP = 'INSERT' THEN
      NEW.created_by := auth.uid();
      NEW.verification_status := 'pending';
      NEW.verified_by := NULL; NEW.verified_at := NULL; NEW.verification_notes := NULL;
    ELSE
      NEW.verification_status := OLD.verification_status;
      NEW.verified_by := OLD.verified_by; NEW.verified_at := OLD.verified_at;
      NEW.verification_notes := OLD.verification_notes; NEW.created_by := OLD.created_by;
      NEW.current_load_kg := OLD.current_load_kg;
    END IF;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER organizations_guard_trg BEFORE INSERT OR UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.organizations_guard();

CREATE OR REPLACE FUNCTION public.organizations_add_creator() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.organization_members (organization_id, user_id, member_role, status)
  VALUES (NEW.id, NEW.created_by, 'admin', 'approved') ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER organizations_add_creator_trg AFTER INSERT ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.organizations_add_creator();

-- Public safe directory of verified orgs (no address / coordinates)
CREATE OR REPLACE FUNCTION public.list_verified_organizations()
RETURNS TABLE (id uuid, name text, org_type public.org_type, is_recipient boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id, name, org_type, is_recipient FROM public.organizations WHERE verification_status='verified' ORDER BY name
$$;
GRANT EXECUTE ON FUNCTION public.list_verified_organizations() TO authenticated;

CREATE TABLE public.organization_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  document_path text NOT NULL,
  document_label text NOT NULL DEFAULT 'Registration certificate',
  submitted_by uuid NOT NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.organization_verifications TO authenticated;
GRANT ALL ON public.organization_verifications TO service_role;
ALTER TABLE public.organization_verifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org admins and super admins read docs" ON public.organization_verifications FOR SELECT TO authenticated
  USING (public.is_org_admin(auth.uid(), organization_id) OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Org admins submit docs" ON public.organization_verifications FOR INSERT TO authenticated
  WITH CHECK (submitted_by = auth.uid() AND public.is_org_admin(auth.uid(), organization_id));

-- ===== VOLUNTEERS =====
CREATE TABLE public.volunteers (
  user_id uuid PRIMARY KEY,
  organization_id uuid REFERENCES public.organizations(id) ON DELETE SET NULL,
  phone text,
  vehicle_type text NOT NULL DEFAULT 'two_wheeler',
  service_area text,
  is_available boolean NOT NULL DEFAULT true,
  verification_status public.verification_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.volunteers TO authenticated;
GRANT ALL ON public.volunteers TO service_role;
ALTER TABLE public.volunteers ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER volunteers_updated BEFORE UPDATE ON public.volunteers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE OR REPLACE FUNCTION public.volunteers_guard() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.has_role(auth.uid(),'super_admin')
     AND NOT (NEW.organization_id IS NOT NULL AND public.is_org_admin(auth.uid(), NEW.organization_id)) THEN
    IF TG_OP = 'INSERT' THEN NEW.verification_status := 'pending';
    ELSE NEW.verification_status := OLD.verification_status; END IF;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER volunteers_guard_trg BEFORE INSERT OR UPDATE ON public.volunteers FOR EACH ROW EXECUTE FUNCTION public.volunteers_guard();
CREATE POLICY "Volunteer reads self, org admin reads org" ON public.volunteers FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR (organization_id IS NOT NULL AND public.is_org_member(auth.uid(), organization_id)) OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Volunteer registers self" ON public.volunteers FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.has_role(auth.uid(),'volunteer'));
CREATE POLICY "Volunteer or org admin updates" ON public.volunteers FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR (organization_id IS NOT NULL AND public.is_org_admin(auth.uid(), organization_id)) OR public.has_role(auth.uid(),'super_admin'))
  WITH CHECK (user_id = auth.uid() OR (organization_id IS NOT NULL AND public.is_org_admin(auth.uid(), organization_id)) OR public.has_role(auth.uid(),'super_admin'));

-- ===== FOOD DONATIONS =====
CREATE TABLE public.food_donations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donor_id uuid NOT NULL DEFAULT auth.uid(),
  donor_org_id uuid REFERENCES public.organizations(id) ON DELETE SET NULL,
  event_type text,
  food_name text NOT NULL,
  category public.food_category NOT NULL,
  is_vegetarian boolean NOT NULL DEFAULT true,
  quantity_kg numeric NOT NULL CHECK (quantity_kg > 0 AND quantity_kg <= 5000),
  remaining_kg numeric NOT NULL DEFAULT 0,
  estimated_servings integer NOT NULL DEFAULT 0 CHECK (estimated_servings >= 0),
  prepared_at timestamptz NOT NULL,
  storage_condition public.storage_condition NOT NULL,
  food_temperature_c numeric,
  packaging_condition public.packaging_condition NOT NULL,
  allergens text[] NOT NULL DEFAULT '{}',
  pickup_address text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  collection_deadline timestamptz NOT NULL,
  contact_phone text NOT NULL,
  photo_paths text[] NOT NULL DEFAULT '{}',
  notes text,
  status public.donation_status NOT NULL DEFAULT 'posted',
  screening jsonb,
  safe_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX food_donations_status_idx ON public.food_donations (status, created_at DESC);
CREATE INDEX food_donations_donor_idx ON public.food_donations (donor_id);
GRANT SELECT, INSERT ON public.food_donations TO authenticated;
GRANT ALL ON public.food_donations TO service_role;
ALTER TABLE public.food_donations ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER food_donations_updated BEFORE UPDATE ON public.food_donations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE OR REPLACE FUNCTION public.food_donations_insert_guard() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL THEN NEW.donor_id := auth.uid(); END IF;
  NEW.status := 'posted';
  NEW.remaining_kg := NEW.quantity_kg;
  NEW.safe_until := NULL;
  RETURN NEW;
END; $$;
CREATE TRIGGER food_donations_insert_guard_trg BEFORE INSERT ON public.food_donations FOR EACH ROW EXECUTE FUNCTION public.food_donations_insert_guard();

CREATE TABLE public.food_safety_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donation_id uuid NOT NULL REFERENCES public.food_donations(id) ON DELETE CASCADE,
  reviewer_id uuid,
  review_type text NOT NULL DEFAULT 'manual' CHECK (review_type IN ('automatic','manual')),
  decision text NOT NULL CHECK (decision IN ('approved','rejected','needs_review')),
  checklist jsonb NOT NULL DEFAULT '{}',
  hours_since_preparation numeric,
  temperature_c numeric,
  approved_safe_until timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX food_safety_donation_idx ON public.food_safety_records (donation_id);
GRANT SELECT ON public.food_safety_records TO authenticated;
GRANT ALL ON public.food_safety_records TO service_role;
ALTER TABLE public.food_safety_records ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.food_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donation_id uuid NOT NULL REFERENCES public.food_donations(id) ON DELETE CASCADE,
  recipient_org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  distance_km numeric NOT NULL,
  score numeric NOT NULL,
  score_breakdown jsonb NOT NULL DEFAULT '{}',
  suggested_kg numeric NOT NULL,
  allocated_kg numeric,
  status public.match_status NOT NULL DEFAULT 'proposed',
  accepted_by uuid,
  accepted_at timestamptz,
  rejection_reason text,
  recipient_feedback text,
  rating integer CHECK (rating BETWEEN 1 AND 5),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (donation_id, recipient_org_id)
);
CREATE INDEX food_matches_org_idx ON public.food_matches (recipient_org_id, status);
GRANT SELECT ON public.food_matches TO authenticated;
GRANT ALL ON public.food_matches TO service_role;
ALTER TABLE public.food_matches ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER food_matches_updated BEFORE UPDATE ON public.food_matches FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES public.food_matches(id) ON DELETE CASCADE,
  volunteer_id uuid NOT NULL,
  assigned_by uuid,
  status public.delivery_status NOT NULL DEFAULT 'assigned',
  assigned_at timestamptz NOT NULL DEFAULT now(),
  picked_up_at timestamptz,
  delivered_at timestamptz,
  pickup_notes text,
  delivery_notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX deliveries_volunteer_idx ON public.deliveries (volunteer_id, status);
CREATE INDEX deliveries_match_idx ON public.deliveries (match_id);
GRANT SELECT ON public.deliveries TO authenticated;
GRANT ALL ON public.deliveries TO service_role;
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

-- access helpers
CREATE OR REPLACE FUNCTION public.is_donation_owner(_user_id uuid, _donation uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.food_donations WHERE id=_donation AND donor_id=_user_id)
$$;
CREATE OR REPLACE FUNCTION public.is_volunteer_for_donation(_user_id uuid, _donation uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.deliveries d JOIN public.food_matches m ON m.id=d.match_id
    WHERE m.donation_id=_donation AND d.volunteer_id=_user_id AND d.status <> 'cancelled')
$$;
CREATE OR REPLACE FUNCTION public.is_volunteer_for_match(_user_id uuid, _match uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.deliveries WHERE match_id=_match AND volunteer_id=_user_id AND status <> 'cancelled')
$$;
CREATE OR REPLACE FUNCTION public.can_access_match(_user_id uuid, _match uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.food_matches m JOIN public.food_donations d ON d.id=m.donation_id
    WHERE m.id=_match AND (d.donor_id=_user_id OR public.is_org_member(_user_id, m.recipient_org_id)))
$$;
CREATE OR REPLACE FUNCTION public.org_visible_via_match(_user_id uuid, _org uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.food_matches m JOIN public.food_donations d ON d.id=m.donation_id
    WHERE m.recipient_org_id=_org AND m.status NOT IN ('proposed','rejected','cancelled') AND d.donor_id=_user_id)
  OR EXISTS (SELECT 1 FROM public.food_matches m JOIN public.deliveries dl ON dl.match_id=m.id
    WHERE m.recipient_org_id=_org AND dl.volunteer_id=_user_id AND dl.status <> 'cancelled')
$$;

CREATE POLICY "Org visibility" ON public.organizations FOR SELECT TO authenticated
  USING (public.is_org_member(auth.uid(), id) OR created_by = auth.uid() OR public.has_role(auth.uid(),'super_admin') OR public.org_visible_via_match(auth.uid(), id));
CREATE POLICY "Authenticated create orgs" ON public.organizations FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY "Org admins update orgs" ON public.organizations FOR UPDATE TO authenticated
  USING (public.is_org_admin(auth.uid(), id) OR public.has_role(auth.uid(),'super_admin'))
  WITH CHECK (public.is_org_admin(auth.uid(), id) OR public.has_role(auth.uid(),'super_admin'));

CREATE POLICY "Donation visibility" ON public.food_donations FOR SELECT TO authenticated
  USING (donor_id = auth.uid() OR public.has_role(auth.uid(),'super_admin')
    OR (public.is_verified_recipient_member(auth.uid()) AND status NOT IN ('cancelled'))
    OR public.is_volunteer_for_donation(auth.uid(), id));
CREATE POLICY "Donors create donations" ON public.food_donations FOR INSERT TO authenticated
  WITH CHECK (donor_id = auth.uid() AND public.has_any_role(auth.uid(), ARRAY['food_donor','super_admin']::public.app_role[]));

CREATE POLICY "Safety record visibility" ON public.food_safety_records FOR SELECT TO authenticated
  USING (public.is_donation_owner(auth.uid(), donation_id) OR public.is_verified_recipient_member(auth.uid()) OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Match visibility" ON public.food_matches FOR SELECT TO authenticated
  USING (public.is_donation_owner(auth.uid(), donation_id) OR public.is_org_member(auth.uid(), recipient_org_id)
    OR public.is_volunteer_for_match(auth.uid(), id) OR public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "Delivery visibility" ON public.deliveries FOR SELECT TO authenticated
  USING (volunteer_id = auth.uid() OR public.can_access_match(auth.uid(), match_id) OR public.has_role(auth.uid(),'super_admin'));

-- ===== NOTIFICATIONS =====
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  category text NOT NULL DEFAULT 'general',
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  link text,
  channel text NOT NULL DEFAULT 'in_app',
  delivery_status text NOT NULL DEFAULT 'delivered',
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON public.notifications (user_id, created_at DESC);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own notifications" ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Mark own read" ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ===== FLOOD: STATIONS, DEVICES, READINGS, ALERTS =====
CREATE TABLE public.river_stations (
  id text PRIMARY KEY,
  name text NOT NULL,
  river text NOT NULL,
  position text NOT NULL CHECK (position IN ('upstream','patna','downstream')),
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  river_km_to_patna numeric,
  warning_level_m numeric,
  danger_level_m numeric,
  highest_flood_level_m numeric,
  thresholds_verified boolean NOT NULL DEFAULT false,
  threshold_source text,
  sort_order integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.river_stations TO anon;
GRANT SELECT, UPDATE ON public.river_stations TO authenticated;
GRANT ALL ON public.river_stations TO service_role;
ALTER TABLE public.river_stations ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER river_stations_updated BEFORE UPDATE ON public.river_stations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE POLICY "Stations public" ON public.river_stations FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Officers manage thresholds" ON public.river_stations FOR UPDATE TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority']::public.app_role[]))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority']::public.app_role[]));

CREATE TABLE public.iot_devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  device_eui text NOT NULL UNIQUE,
  name text NOT NULL,
  device_type public.device_type NOT NULL,
  station_id text REFERENCES public.river_stations(id) ON DELETE SET NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  is_simulated boolean NOT NULL DEFAULT false,
  battery_pct numeric,
  firmware text,
  last_seen_at timestamptz,
  active boolean NOT NULL DEFAULT true,
  created_by uuid DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.iot_devices TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.iot_devices TO authenticated;
GRANT ALL ON public.iot_devices TO service_role;
ALTER TABLE public.iot_devices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Devices public" ON public.iot_devices FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Operators insert devices" ON public.iot_devices FOR INSERT TO authenticated
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['super_admin','iot_operator']::public.app_role[]));
CREATE POLICY "Operators update devices" ON public.iot_devices FOR UPDATE TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['super_admin','iot_operator']::public.app_role[]))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['super_admin','iot_operator']::public.app_role[]));
CREATE POLICY "Operators delete devices" ON public.iot_devices FOR DELETE TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['super_admin','iot_operator']::public.app_role[]));

-- device secrets: service role only
CREATE TABLE public.device_credentials (
  device_id uuid PRIMARY KEY REFERENCES public.iot_devices(id) ON DELETE CASCADE,
  key_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.device_credentials TO service_role;
ALTER TABLE public.device_credentials ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.sensor_readings (
  id bigserial PRIMARY KEY,
  device_id uuid NOT NULL REFERENCES public.iot_devices(id) ON DELETE CASCADE,
  metric text NOT NULL CHECK (metric IN ('water_level_m','rainfall_mm','soil_moisture_pct','temperature_c','humidity_pct','wind_speed_ms','battery_pct')),
  value numeric NOT NULL,
  recorded_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  is_simulated boolean NOT NULL DEFAULT false,
  source text NOT NULL DEFAULT 'http'
);
CREATE INDEX sensor_readings_device_metric_idx ON public.sensor_readings (device_id, metric, recorded_at DESC);
GRANT SELECT ON public.sensor_readings TO anon, authenticated;
GRANT ALL ON public.sensor_readings TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.sensor_readings_id_seq TO service_role;
ALTER TABLE public.sensor_readings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Readings public" ON public.sensor_readings FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.flood_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  message text NOT NULL,
  message_hi text,
  risk_level public.risk_level NOT NULL,
  area text NOT NULL,
  station_id text REFERENCES public.river_stations(id) ON DELETE SET NULL,
  basis text,
  is_drill boolean NOT NULL DEFAULT false,
  status public.alert_status NOT NULL DEFAULT 'active',
  created_by uuid NOT NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  resolved_by uuid
);
CREATE INDEX flood_alerts_status_idx ON public.flood_alerts (status, created_at DESC);
GRANT SELECT ON public.flood_alerts TO anon;
GRANT SELECT, INSERT, UPDATE ON public.flood_alerts TO authenticated;
GRANT ALL ON public.flood_alerts TO service_role;
ALTER TABLE public.flood_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Alerts public" ON public.flood_alerts FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Officers create alerts" ON public.flood_alerts FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority']::public.app_role[]));
CREATE POLICY "Officers update alerts" ON public.flood_alerts FOR UPDATE TO authenticated
  USING (public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority']::public.app_role[]))
  WITH CHECK (public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority']::public.app_role[]));

CREATE TABLE public.alert_acknowledgements (
  alert_id uuid NOT NULL REFERENCES public.flood_alerts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid(),
  note text,
  acknowledged_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (alert_id, user_id)
);
GRANT SELECT, INSERT ON public.alert_acknowledgements TO authenticated;
GRANT ALL ON public.alert_acknowledgements TO service_role;
ALTER TABLE public.alert_acknowledgements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Officers read acks" ON public.alert_acknowledgements FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority','iot_operator']::public.app_role[]));
CREATE POLICY "Officers acknowledge" ON public.alert_acknowledgements FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.has_any_role(auth.uid(), ARRAY['super_admin','disaster_officer','municipal_authority','iot_operator','ngo_admin']::public.app_role[]));

-- ===== AUDIT + SETTINGS =====
CREATE TABLE public.audit_logs (
  id bigserial PRIMARY KEY,
  actor_id uuid,
  action text NOT NULL,
  entity text NOT NULL,
  entity_id text,
  details jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_created_idx ON public.audit_logs (created_at DESC);
GRANT SELECT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.audit_logs_id_seq TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Super admins read audit" ON public.audit_logs FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'super_admin'));

CREATE TABLE public.app_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  description text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.app_settings TO anon;
GRANT SELECT, UPDATE ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Settings public" ON public.app_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Super admins edit settings" ON public.app_settings FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'super_admin')) WITH CHECK (public.has_role(auth.uid(),'super_admin'));
INSERT INTO public.app_settings (key, value, description) VALUES
  ('serving_size_kg', '0.4', 'Kilograms of food counted as one meal when estimating meals served'),
  ('match_radius_km', '15', 'Maximum distance for recipient matching'),
  ('max_matches_per_donation', '5', 'Maximum recipient organizations proposed per donation');

-- ===== SIGNUP TRIGGER =====
CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  requested text := COALESCE(NEW.raw_user_meta_data->>'requested_role', 'public_user');
  chosen public.app_role;
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, preferred_language)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
          NEW.raw_user_meta_data->>'phone', COALESCE(NEW.raw_user_meta_data->>'preferred_language','en'))
  ON CONFLICT (id) DO NOTHING;

  IF requested IN ('food_donor','ngo_admin','recipient_org','volunteer','public_user') THEN
    chosen := requested::public.app_role;
  ELSE
    chosen := 'public_user';
  END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, chosen) ON CONFLICT DO NOTHING;

  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'super_admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'super_admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ===== EXPIRY =====
CREATE OR REPLACE FUNCTION public.expire_stale_donations() RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n integer;
BEGIN
  WITH expired AS (
    UPDATE public.food_donations SET status = 'expired'
    WHERE status IN ('posted','safety_review','verified','matched','accepted','pickup_assigned')
      AND COALESCE(LEAST(safe_until, collection_deadline), collection_deadline) < now()
    RETURNING id
  )
  SELECT count(*) INTO n FROM expired;
  UPDATE public.food_matches m SET status = 'cancelled', rejection_reason = COALESCE(rejection_reason, 'Donation expired')
    FROM public.food_donations d
    WHERE d.id = m.donation_id AND d.status = 'expired' AND m.status IN ('proposed','accepted','pickup_assigned');
  UPDATE public.deliveries dl SET status = 'cancelled'
    FROM public.food_matches m WHERE m.id = dl.match_id AND m.status = 'cancelled' AND dl.status = 'assigned';
  RETURN n;
END; $$;
REVOKE EXECUTE ON FUNCTION public.expire_stale_donations() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.expire_stale_donations() TO authenticated, service_role;

-- ===== PUBLIC IMPACT STATS =====
CREATE OR REPLACE FUNCTION public.get_impact_stats() RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT jsonb_build_object(
    'donated_kg', COALESCE((SELECT sum(quantity_kg) FROM food_donations WHERE status NOT IN ('cancelled')), 0),
    'delivered_kg', COALESCE((SELECT sum(allocated_kg) FROM food_matches WHERE status IN ('delivered','completed')), 0),
    'donations_total', (SELECT count(*) FROM food_donations),
    'donations_completed', (SELECT count(*) FROM food_donations WHERE status IN ('delivered','completed')),
    'donations_expired_rejected', (SELECT count(*) FROM food_donations WHERE status IN ('expired','rejected')),
    'verified_recipient_orgs', (SELECT count(*) FROM organizations WHERE verification_status='verified' AND is_recipient),
    'volunteers', (SELECT count(*) FROM volunteers),
    'serving_size_kg', COALESCE((SELECT (value#>>'{}')::numeric FROM app_settings WHERE key='serving_size_kg'), 0.4),
    'stations', (SELECT count(*) FROM river_stations),
    'devices_total', (SELECT count(*) FROM iot_devices),
    'devices_active_24h', (SELECT count(*) FROM iot_devices WHERE last_seen_at > now() - interval '24 hours'),
    'readings_total', (SELECT count(*) FROM sensor_readings),
    'readings_simulated', (SELECT count(*) FROM sensor_readings WHERE is_simulated),
    'alerts_total', (SELECT count(*) FROM flood_alerts WHERE NOT is_drill),
    'alerts_active', (SELECT count(*) FROM flood_alerts WHERE status='active')
  )
$$;
GRANT EXECUTE ON FUNCTION public.get_impact_stats() TO anon, authenticated;

-- ===== SEED: Ganga basin stations (thresholds unverified until confirmed by an officer) =====
INSERT INTO public.river_stations (id, name, river, position, latitude, longitude, river_km_to_patna, warning_level_m, danger_level_m, highest_flood_level_m, thresholds_verified, threshold_source, sort_order) VALUES
 ('buxar','Buxar','Ganga','upstream',25.5650,83.9777,160,59.32,60.32,62.09,false,'Reference values from public CWC flood bulletins — confirm before operational use',1),
 ('koelwar','Koelwar','Son','upstream',25.5800,84.7930,60,54.52,55.52,58.88,false,'Reference values from public CWC flood bulletins — confirm before operational use',2),
 ('digha_ghat','Digha Ghat, Patna','Ganga','patna',25.6560,85.0950,0,49.45,50.45,52.52,false,'Reference values from public CWC flood bulletins — confirm before operational use',3),
 ('gandhi_ghat','Gandhi Ghat, Patna','Ganga','patna',25.6200,85.1650,0,47.60,48.60,50.52,false,'Reference values from public CWC flood bulletins — confirm before operational use',4),
 ('hajipur','Hajipur','Gandak','upstream',25.6900,85.2100,10,49.32,50.32,50.93,false,'Reference values from public CWC flood bulletins — confirm before operational use',5),
 ('dumariaghat','Dumariaghat','Gandak','upstream',26.3300,84.4600,140,61.22,62.22,64.13,false,'Reference values from public CWC flood bulletins — confirm before operational use',6),
 ('sripalpur','Sripalpur','Punpun','upstream',25.5200,85.1500,25,49.60,50.60,53.91,false,'Reference values from public CWC flood bulletins — confirm before operational use',7),
 ('hathidah','Hathidah','Ganga','downstream',25.3700,85.9900,-95,40.76,41.76,43.17,false,'Reference values from public CWC flood bulletins — confirm before operational use',8);

-- ===== REALTIME =====
ALTER PUBLICATION supabase_realtime ADD TABLE public.food_donations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.food_matches;
ALTER PUBLICATION supabase_realtime ADD TABLE public.deliveries;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.flood_alerts;
