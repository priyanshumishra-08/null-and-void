# JAL-RAKSHAK roadmap

## In progress / done this build
- [ ] Phase 1: Design system, landing page, navigation, auth (email + Google + Lovable), profiles
- [ ] Phase 2: Database schema, roles (9), RLS, storage buckets, role-based dashboard
- [ ] Phase 3: ANN-SETU donor flow, safety screening + review, matching engine, NGO accept/split, volunteer pickup/delivery, expiry
- [ ] Phase 4: Flood Intelligence (real Open-Meteo weather + GloFAS river discharge), Live Map (Leaflet), stations, thresholds
- [ ] Municipal dashboard: alerts (create/ack/resolve, history), device management, simulated readings
- [ ] Admin: verify organizations, assign roles, settings (serving size)
- [ ] Impact analytics (donated vs delivered, meals, flood stats)
- [ ] Telemetry ingestion endpoint for MQTT/LoRaWAN bridge (device key auth)
- [ ] API docs page + external service scaffolds (Node MQTT bridge, FastAPI predictor) with setup notes
- [ ] Tests for food-safety screening + matching scoring

## Blocked on external setup (cannot run inside the app)
- MQTT broker / ChirpStack / ESP32 hardware — needs user-hosted services
- TensorFlow FastAPI model server — needs hosting + PREDICTION_API_URL
- MongoDB Atlas telemetry store — needs connection string; Cloud DB used meanwhile
- SMS / WhatsApp / push providers — need credentials
