export const ALL_ROLES = [
  "super_admin",
  "municipal_authority",
  "disaster_officer",
  "iot_operator",
  "ngo_admin",
  "food_donor",
  "recipient_org",
  "volunteer",
  "public_user",
] as const;

export type AppRole = (typeof ALL_ROLES)[number];

export const ROLE_LABELS: Record<AppRole, string> = {
  super_admin: "Super Admin",
  municipal_authority: "Municipal Authority",
  disaster_officer: "Disaster Management Officer",
  iot_operator: "IoT Operator",
  ngo_admin: "NGO Administrator",
  food_donor: "Food Donor",
  recipient_org: "Recipient Organization",
  volunteer: "Volunteer",
  public_user: "Public User",
};

/** Roles a person may pick for themselves at sign-up. Everything else is granted by a Super Admin. */
export const SELF_SERVICE_ROLES: AppRole[] = [
  "food_donor",
  "ngo_admin",
  "recipient_org",
  "volunteer",
  "public_user",
];

export const FLOOD_OFFICER_ROLES: AppRole[] = ["super_admin", "disaster_officer", "municipal_authority"];
export const DEVICE_ROLES: AppRole[] = ["super_admin", "iot_operator"];
export const RECIPIENT_ROLES: AppRole[] = ["ngo_admin", "recipient_org"];

export function hasAny(roles: readonly string[] | undefined, wanted: readonly AppRole[]) {
  return !!roles?.some((r) => (wanted as readonly string[]).includes(r));
}
