/** ANN-SETU matching engine: pure scoring so it can be tested and reused by the server. */

export interface DonationForMatch {
  latitude: number;
  longitude: number;
  remainingKg: number;
  isVegetarian: boolean;
  allergens: string[];
  safeUntil: Date;
}

export interface RecipientForMatch {
  id: string;
  name: string;
  latitude: number | null;
  longitude: number | null;
  capacityKg: number;
  currentLoadKg: number;
  vegetarianOnly: boolean;
  allergenExclusions: string[];
  availableVolunteers: number;
}

export interface MatchCandidate {
  orgId: string;
  name: string;
  distanceKm: number;
  travelMinutes: number;
  availableCapacityKg: number;
  score: number;
  breakdown: { distance: number; capacity: number; volunteers: number; urgency: number };
}

export interface Rejection {
  orgId: string;
  name: string;
  reason: string;
}

/** Assumed average urban travel speed in Patna traffic. */
export const AVG_SPEED_KMH = 18;
export const HANDOVER_BUFFER_MIN = 20;

export function haversineKm(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(aLat)) * Math.cos(toRad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function evaluateRecipient(
  donation: DonationForMatch,
  org: RecipientForMatch,
  radiusKm: number,
  now: Date = new Date(),
): { ok: true; candidate: MatchCandidate } | { ok: false; rejection: Rejection } {
  const reject = (reason: string) => ({ ok: false as const, rejection: { orgId: org.id, name: org.name, reason } });
  if (org.latitude == null || org.longitude == null) return reject("No location on file");
  if (org.vegetarianOnly && !donation.isVegetarian) return reject("Accepts vegetarian food only");
  const clash = donation.allergens.filter((a) => org.allergenExclusions.map((x) => x.toLowerCase()).includes(a.toLowerCase()));
  if (clash.length) return reject(`Allergen conflict: ${clash.join(", ")}`);
  const available = Math.max(0, org.capacityKg - org.currentLoadKg);
  if (available <= 0) return reject("No receiving capacity left");

  // Road distance is typically ~1.3x straight-line distance in dense cities.
  const distanceKm = haversineKm(donation.latitude, donation.longitude, org.latitude, org.longitude) * 1.3;
  if (distanceKm > radiusKm) return reject(`Too far (${distanceKm.toFixed(1)} km)`);
  const travelMinutes = (distanceKm / AVG_SPEED_KMH) * 60;
  const safeMinutesLeft = (donation.safeUntil.getTime() - now.getTime()) / 60_000;
  if (travelMinutes * 2 + HANDOVER_BUFFER_MIN > safeMinutesLeft) return reject("Cannot be reached within the safe window");

  const distance = 40 * (1 - distanceKm / radiusKm);
  const capacity = 25 * Math.min(1, available / Math.max(1, donation.remainingKg));
  const volunteers = org.availableVolunteers > 0 ? 15 : 0;
  const slack = Math.min(1, (safeMinutesLeft - travelMinutes * 2) / 180);
  const urgency = 20 * Math.max(0, 1 - slack) * (1 - distanceKm / radiusKm) + 20 * slack * 0.5;
  const score = Math.round((distance + capacity + volunteers + urgency) * 10) / 10;

  return {
    ok: true,
    candidate: {
      orgId: org.id,
      name: org.name,
      distanceKm: Math.round(distanceKm * 10) / 10,
      travelMinutes: Math.round(travelMinutes),
      availableCapacityKg: available,
      score,
      breakdown: {
        distance: Math.round(distance * 10) / 10,
        capacity: Math.round(capacity * 10) / 10,
        volunteers,
        urgency: Math.round(urgency * 10) / 10,
      },
    },
  };
}

/** Rank recipients and split the remaining food across them by available capacity. */
export function planMatches(
  donation: DonationForMatch,
  orgs: RecipientForMatch[],
  opts: { radiusKm: number; maxMatches: number },
  now: Date = new Date(),
) {
  const candidates: MatchCandidate[] = [];
  const rejections: Rejection[] = [];
  for (const org of orgs) {
    const r = evaluateRecipient(donation, org, opts.radiusKm, now);
    if (r.ok) candidates.push(r.candidate);
    else rejections.push(r.rejection);
  }
  candidates.sort((a, b) => b.score - a.score);
  const picked = candidates.slice(0, opts.maxMatches);
  let left = donation.remainingKg;
  const allocations = picked.map((c) => {
    const kg = Math.max(0, Math.min(c.availableCapacityKg, left));
    left -= kg;
    return { ...c, suggestedKg: Math.round(kg * 10) / 10 };
  });
  return { allocations: allocations.filter((a) => a.suggestedKg > 0), rejections, unallocatedKg: Math.max(0, Math.round(left * 10) / 10) };
}
