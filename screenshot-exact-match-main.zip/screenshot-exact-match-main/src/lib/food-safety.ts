/**
 * Automatic food-safety screening for ANN-SETU.
 *
 * These are conservative time/temperature rules based on general food-hygiene
 * guidance (FSSAI Schedule 4 good hygiene practices and the widely used
 * "2-hour rule" for cooked food held at ambient temperature). They are an
 * automatic first screen only — every donation still needs a human safety
 * review before it can be matched.
 */

export type FoodCategory =
  | "cooked_meal"
  | "rice_grains"
  | "bread_roti"
  | "curry_dal"
  | "sweets_dessert"
  | "fruits_vegetables"
  | "packaged"
  | "beverages"
  | "other";
export type StorageCondition = "hot_held" | "refrigerated" | "room_temperature" | "frozen";
export type PackagingCondition = "sealed" | "covered_containers" | "open_trays" | "damaged";

export interface ScreeningInput {
  category: FoodCategory;
  storage: StorageCondition;
  packaging: PackagingCondition;
  preparedAt: Date;
  temperatureC?: number | null;
  collectionDeadline: Date;
}

export type ScreeningResult = "pass" | "caution" | "fail";

export interface Screening {
  result: ScreeningResult;
  effectiveStorage: StorageCondition;
  hoursSincePreparation: number;
  /** Latest time the food can be considered safe to serve, or null when it failed. */
  maxSafeUntil: string | null;
  reasons: string[];
}

/** Minimum time needed for pickup + delivery once a donation is approved. */
export const MIN_HANDLING_MINUTES = 30;

/** Safe holding windows in hours, from the time of preparation. */
export function safeWindowHours(category: FoodCategory, storage: StorageCondition, packaging: PackagingCondition): number {
  if (category === "packaged" && packaging === "sealed") return 7 * 24;
  if (category === "fruits_vegetables") {
    return storage === "refrigerated" || storage === "frozen" ? 72 : 24;
  }
  const lowerRisk = category === "bread_roti";
  switch (storage) {
    case "room_temperature":
      return lowerRisk ? 4 : 2;
    case "hot_held":
      return 4;
    case "refrigerated":
      return 24;
    case "frozen":
      return 72;
  }
}

/** If a measured temperature contradicts the declared storage, fall back to the riskier condition. */
export function effectiveStorage(storage: StorageCondition, temperatureC?: number | null): StorageCondition {
  if (temperatureC == null || Number.isNaN(temperatureC)) return storage;
  if (storage === "hot_held" && temperatureC < 60) return "room_temperature";
  if (storage === "refrigerated" && temperatureC > 5) return "room_temperature";
  if (storage === "frozen" && temperatureC > -12) return temperatureC > 5 ? "room_temperature" : "refrigerated";
  return storage;
}

export function screenFood(input: ScreeningInput, now: Date = new Date()): Screening {
  const reasons: string[] = [];
  const hours = (now.getTime() - input.preparedAt.getTime()) / 3_600_000;
  const storage = effectiveStorage(input.storage, input.temperatureC);
  const round = (n: number) => Math.round(n * 10) / 10;

  if (input.preparedAt.getTime() - now.getTime() > 10 * 60_000) {
    return { result: "fail", effectiveStorage: storage, hoursSincePreparation: round(hours), maxSafeUntil: null, reasons: ["Preparation time is in the future — please correct it."] };
  }
  if (input.packaging === "damaged") {
    return { result: "fail", effectiveStorage: storage, hoursSincePreparation: round(hours), maxSafeUntil: null, reasons: ["Damaged packaging cannot be accepted (contamination risk)."] };
  }
  if (storage !== input.storage) {
    reasons.push(`Measured ${input.temperatureC}°C does not match "${input.storage.replace("_", " ")}" — treated as ${storage.replace("_", " ")}.`);
  }

  const windowH = safeWindowHours(input.category, storage, input.packaging);
  const maxSafe = new Date(input.preparedAt.getTime() + windowH * 3_600_000);
  const minutesLeft = (maxSafe.getTime() - now.getTime()) / 60_000;

  if (minutesLeft <= 0) {
    reasons.push(`Exceeded the ${windowH}-hour safe window for this food and storage condition.`);
    return { result: "fail", effectiveStorage: storage, hoursSincePreparation: round(hours), maxSafeUntil: null, reasons };
  }
  if (minutesLeft < MIN_HANDLING_MINUTES) {
    reasons.push(`Only ${Math.round(minutesLeft)} minutes of safe time left — not enough for pickup and delivery.`);
    return { result: "fail", effectiveStorage: storage, hoursSincePreparation: round(hours), maxSafeUntil: null, reasons };
  }

  let result: ScreeningResult = "pass";
  if (input.packaging === "open_trays") {
    result = "caution";
    reasons.push("Food is in open trays — must be transferred to covered, food-grade containers before pickup.");
  }
  if (input.storage === "hot_held" && input.temperatureC == null) {
    result = "caution";
    reasons.push("Hot-held food without a temperature reading — reviewer should confirm it is above 60°C.");
  }
  if (input.category === "packaged" && input.packaging === "sealed") {
    reasons.push("Sealed packaged food — reviewer must check the printed best-before date.");
  }
  if (minutesLeft < 90) {
    result = "caution";
    reasons.push(`Less than ${Math.round(minutesLeft)} minutes of safe time left — prioritise a nearby recipient.`);
  }

  const deadline = input.collectionDeadline.getTime() < maxSafe.getTime() ? input.collectionDeadline : maxSafe;
  if (input.collectionDeadline.getTime() > maxSafe.getTime()) {
    reasons.push("Collection deadline is later than the safe window; the safe window will be used.");
  }
  if (reasons.length === 0) reasons.push(`Within the ${windowH}-hour safe window for ${storage.replace("_", " ")} storage.`);

  return { result, effectiveStorage: storage, hoursSincePreparation: round(hours), maxSafeUntil: deadline.toISOString(), reasons };
}
