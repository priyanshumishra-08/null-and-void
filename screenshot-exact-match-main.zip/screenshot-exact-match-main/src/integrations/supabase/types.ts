export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      alert_acknowledgements: {
        Row: {
          acknowledged_at: string
          alert_id: string
          note: string | null
          user_id: string
        }
        Insert: {
          acknowledged_at?: string
          alert_id: string
          note?: string | null
          user_id?: string
        }
        Update: {
          acknowledged_at?: string
          alert_id?: string
          note?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "alert_acknowledgements_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "flood_alerts"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          description: string | null
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          description?: string | null
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          description?: string | null
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          details: Json
          entity: string
          entity_id: string | null
          id: number
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          entity: string
          entity_id?: string | null
          id?: number
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          details?: Json
          entity?: string
          entity_id?: string | null
          id?: number
        }
        Relationships: []
      }
      deliveries: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          created_at: string
          delivered_at: string | null
          delivery_notes: string | null
          id: string
          match_id: string
          picked_up_at: string | null
          pickup_notes: string | null
          status: Database["public"]["Enums"]["delivery_status"]
          volunteer_id: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          delivered_at?: string | null
          delivery_notes?: string | null
          id?: string
          match_id: string
          picked_up_at?: string | null
          pickup_notes?: string | null
          status?: Database["public"]["Enums"]["delivery_status"]
          volunteer_id: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          delivered_at?: string | null
          delivery_notes?: string | null
          id?: string
          match_id?: string
          picked_up_at?: string | null
          pickup_notes?: string | null
          status?: Database["public"]["Enums"]["delivery_status"]
          volunteer_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deliveries_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "food_matches"
            referencedColumns: ["id"]
          },
        ]
      }
      device_credentials: {
        Row: {
          created_at: string
          device_id: string
          key_hash: string
        }
        Insert: {
          created_at?: string
          device_id: string
          key_hash: string
        }
        Update: {
          created_at?: string
          device_id?: string
          key_hash?: string
        }
        Relationships: [
          {
            foreignKeyName: "device_credentials_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: true
            referencedRelation: "iot_devices"
            referencedColumns: ["id"]
          },
        ]
      }
      flood_alerts: {
        Row: {
          area: string
          basis: string | null
          created_at: string
          created_by: string
          id: string
          is_drill: boolean
          message: string
          message_hi: string | null
          resolved_at: string | null
          resolved_by: string | null
          risk_level: Database["public"]["Enums"]["risk_level"]
          station_id: string | null
          status: Database["public"]["Enums"]["alert_status"]
          title: string
        }
        Insert: {
          area: string
          basis?: string | null
          created_at?: string
          created_by?: string
          id?: string
          is_drill?: boolean
          message: string
          message_hi?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          risk_level: Database["public"]["Enums"]["risk_level"]
          station_id?: string | null
          status?: Database["public"]["Enums"]["alert_status"]
          title: string
        }
        Update: {
          area?: string
          basis?: string | null
          created_at?: string
          created_by?: string
          id?: string
          is_drill?: boolean
          message?: string
          message_hi?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          risk_level?: Database["public"]["Enums"]["risk_level"]
          station_id?: string | null
          status?: Database["public"]["Enums"]["alert_status"]
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "flood_alerts_station_id_fkey"
            columns: ["station_id"]
            isOneToOne: false
            referencedRelation: "river_stations"
            referencedColumns: ["id"]
          },
        ]
      }
      food_donations: {
        Row: {
          allergens: string[]
          category: Database["public"]["Enums"]["food_category"]
          collection_deadline: string
          contact_phone: string
          created_at: string
          donor_id: string
          donor_org_id: string | null
          estimated_servings: number
          event_type: string | null
          food_name: string
          food_temperature_c: number | null
          id: string
          is_vegetarian: boolean
          latitude: number
          longitude: number
          notes: string | null
          packaging_condition: Database["public"]["Enums"]["packaging_condition"]
          photo_paths: string[]
          pickup_address: string
          prepared_at: string
          quantity_kg: number
          remaining_kg: number
          safe_until: string | null
          screening: Json | null
          status: Database["public"]["Enums"]["donation_status"]
          storage_condition: Database["public"]["Enums"]["storage_condition"]
          updated_at: string
        }
        Insert: {
          allergens?: string[]
          category: Database["public"]["Enums"]["food_category"]
          collection_deadline: string
          contact_phone: string
          created_at?: string
          donor_id?: string
          donor_org_id?: string | null
          estimated_servings?: number
          event_type?: string | null
          food_name: string
          food_temperature_c?: number | null
          id?: string
          is_vegetarian?: boolean
          latitude: number
          longitude: number
          notes?: string | null
          packaging_condition: Database["public"]["Enums"]["packaging_condition"]
          photo_paths?: string[]
          pickup_address: string
          prepared_at: string
          quantity_kg: number
          remaining_kg?: number
          safe_until?: string | null
          screening?: Json | null
          status?: Database["public"]["Enums"]["donation_status"]
          storage_condition: Database["public"]["Enums"]["storage_condition"]
          updated_at?: string
        }
        Update: {
          allergens?: string[]
          category?: Database["public"]["Enums"]["food_category"]
          collection_deadline?: string
          contact_phone?: string
          created_at?: string
          donor_id?: string
          donor_org_id?: string | null
          estimated_servings?: number
          event_type?: string | null
          food_name?: string
          food_temperature_c?: number | null
          id?: string
          is_vegetarian?: boolean
          latitude?: number
          longitude?: number
          notes?: string | null
          packaging_condition?: Database["public"]["Enums"]["packaging_condition"]
          photo_paths?: string[]
          pickup_address?: string
          prepared_at?: string
          quantity_kg?: number
          remaining_kg?: number
          safe_until?: string | null
          screening?: Json | null
          status?: Database["public"]["Enums"]["donation_status"]
          storage_condition?: Database["public"]["Enums"]["storage_condition"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "food_donations_donor_org_id_fkey"
            columns: ["donor_org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      food_matches: {
        Row: {
          accepted_at: string | null
          accepted_by: string | null
          allocated_kg: number | null
          created_at: string
          distance_km: number
          donation_id: string
          id: string
          rating: number | null
          recipient_feedback: string | null
          recipient_org_id: string
          rejection_reason: string | null
          score: number
          score_breakdown: Json
          status: Database["public"]["Enums"]["match_status"]
          suggested_kg: number
          updated_at: string
        }
        Insert: {
          accepted_at?: string | null
          accepted_by?: string | null
          allocated_kg?: number | null
          created_at?: string
          distance_km: number
          donation_id: string
          id?: string
          rating?: number | null
          recipient_feedback?: string | null
          recipient_org_id: string
          rejection_reason?: string | null
          score: number
          score_breakdown?: Json
          status?: Database["public"]["Enums"]["match_status"]
          suggested_kg: number
          updated_at?: string
        }
        Update: {
          accepted_at?: string | null
          accepted_by?: string | null
          allocated_kg?: number | null
          created_at?: string
          distance_km?: number
          donation_id?: string
          id?: string
          rating?: number | null
          recipient_feedback?: string | null
          recipient_org_id?: string
          rejection_reason?: string | null
          score?: number
          score_breakdown?: Json
          status?: Database["public"]["Enums"]["match_status"]
          suggested_kg?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "food_matches_donation_id_fkey"
            columns: ["donation_id"]
            isOneToOne: false
            referencedRelation: "food_donations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "food_matches_recipient_org_id_fkey"
            columns: ["recipient_org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      food_safety_records: {
        Row: {
          approved_safe_until: string | null
          checklist: Json
          created_at: string
          decision: string
          donation_id: string
          hours_since_preparation: number | null
          id: string
          notes: string | null
          review_type: string
          reviewer_id: string | null
          temperature_c: number | null
        }
        Insert: {
          approved_safe_until?: string | null
          checklist?: Json
          created_at?: string
          decision: string
          donation_id: string
          hours_since_preparation?: number | null
          id?: string
          notes?: string | null
          review_type?: string
          reviewer_id?: string | null
          temperature_c?: number | null
        }
        Update: {
          approved_safe_until?: string | null
          checklist?: Json
          created_at?: string
          decision?: string
          donation_id?: string
          hours_since_preparation?: number | null
          id?: string
          notes?: string | null
          review_type?: string
          reviewer_id?: string | null
          temperature_c?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "food_safety_records_donation_id_fkey"
            columns: ["donation_id"]
            isOneToOne: false
            referencedRelation: "food_donations"
            referencedColumns: ["id"]
          },
        ]
      }
      iot_devices: {
        Row: {
          active: boolean
          battery_pct: number | null
          created_at: string
          created_by: string | null
          device_eui: string
          device_type: Database["public"]["Enums"]["device_type"]
          firmware: string | null
          id: string
          is_simulated: boolean
          last_seen_at: string | null
          latitude: number
          longitude: number
          name: string
          station_id: string | null
        }
        Insert: {
          active?: boolean
          battery_pct?: number | null
          created_at?: string
          created_by?: string | null
          device_eui: string
          device_type: Database["public"]["Enums"]["device_type"]
          firmware?: string | null
          id?: string
          is_simulated?: boolean
          last_seen_at?: string | null
          latitude: number
          longitude: number
          name: string
          station_id?: string | null
        }
        Update: {
          active?: boolean
          battery_pct?: number | null
          created_at?: string
          created_by?: string | null
          device_eui?: string
          device_type?: Database["public"]["Enums"]["device_type"]
          firmware?: string | null
          id?: string
          is_simulated?: boolean
          last_seen_at?: string | null
          latitude?: number
          longitude?: number
          name?: string
          station_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "iot_devices_station_id_fkey"
            columns: ["station_id"]
            isOneToOne: false
            referencedRelation: "river_stations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string
          category: string
          channel: string
          created_at: string
          delivery_status: string
          id: string
          link: string | null
          read_at: string | null
          title: string
          user_id: string
        }
        Insert: {
          body?: string
          category?: string
          channel?: string
          created_at?: string
          delivery_status?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title: string
          user_id: string
        }
        Update: {
          body?: string
          category?: string
          channel?: string
          created_at?: string
          delivery_status?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      organization_members: {
        Row: {
          created_at: string
          member_role: string
          organization_id: string
          status: Database["public"]["Enums"]["member_status"]
          user_id: string
        }
        Insert: {
          created_at?: string
          member_role?: string
          organization_id: string
          status?: Database["public"]["Enums"]["member_status"]
          user_id: string
        }
        Update: {
          created_at?: string
          member_role?: string
          organization_id?: string
          status?: Database["public"]["Enums"]["member_status"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_members_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_verifications: {
        Row: {
          created_at: string
          document_label: string
          document_path: string
          id: string
          organization_id: string
          submitted_by: string
        }
        Insert: {
          created_at?: string
          document_label?: string
          document_path: string
          id?: string
          organization_id: string
          submitted_by?: string
        }
        Update: {
          created_at?: string
          document_label?: string
          document_path?: string
          id?: string
          organization_id?: string
          submitted_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_verifications_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          address: string
          allergen_exclusions: string[]
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          created_by: string
          current_load_kg: number
          food_requirements: string | null
          id: string
          is_recipient: boolean
          latitude: number | null
          longitude: number | null
          name: string
          operating_hours: string | null
          org_type: Database["public"]["Enums"]["org_type"]
          pickup_preference: string | null
          receiving_capacity_kg: number
          registration_number: string | null
          updated_at: string
          vegetarian_only: boolean
          verification_notes: string | null
          verification_status: Database["public"]["Enums"]["verification_status"]
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          address?: string
          allergen_exclusions?: string[]
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          created_by?: string
          current_load_kg?: number
          food_requirements?: string | null
          id?: string
          is_recipient?: boolean
          latitude?: number | null
          longitude?: number | null
          name: string
          operating_hours?: string | null
          org_type: Database["public"]["Enums"]["org_type"]
          pickup_preference?: string | null
          receiving_capacity_kg?: number
          registration_number?: string | null
          updated_at?: string
          vegetarian_only?: boolean
          verification_notes?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          address?: string
          allergen_exclusions?: string[]
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          created_by?: string
          current_load_kg?: number
          food_requirements?: string | null
          id?: string
          is_recipient?: boolean
          latitude?: number | null
          longitude?: number | null
          name?: string
          operating_hours?: string | null
          org_type?: Database["public"]["Enums"]["org_type"]
          pickup_preference?: string | null
          receiving_capacity_kg?: number
          registration_number?: string | null
          updated_at?: string
          vegetarian_only?: boolean
          verification_notes?: string | null
          verification_status?: Database["public"]["Enums"]["verification_status"]
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string
          id: string
          phone: string | null
          preferred_language: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          full_name?: string
          id: string
          phone?: string | null
          preferred_language?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          phone?: string | null
          preferred_language?: string
          updated_at?: string
        }
        Relationships: []
      }
      river_stations: {
        Row: {
          danger_level_m: number | null
          highest_flood_level_m: number | null
          id: string
          latitude: number
          longitude: number
          name: string
          position: string
          river: string
          river_km_to_patna: number | null
          sort_order: number
          threshold_source: string | null
          thresholds_verified: boolean
          updated_at: string
          warning_level_m: number | null
        }
        Insert: {
          danger_level_m?: number | null
          highest_flood_level_m?: number | null
          id: string
          latitude: number
          longitude: number
          name: string
          position: string
          river: string
          river_km_to_patna?: number | null
          sort_order?: number
          threshold_source?: string | null
          thresholds_verified?: boolean
          updated_at?: string
          warning_level_m?: number | null
        }
        Update: {
          danger_level_m?: number | null
          highest_flood_level_m?: number | null
          id?: string
          latitude?: number
          longitude?: number
          name?: string
          position?: string
          river?: string
          river_km_to_patna?: number | null
          sort_order?: number
          threshold_source?: string | null
          thresholds_verified?: boolean
          updated_at?: string
          warning_level_m?: number | null
        }
        Relationships: []
      }
      sensor_readings: {
        Row: {
          device_id: string
          id: number
          is_simulated: boolean
          metric: string
          received_at: string
          recorded_at: string
          source: string
          value: number
        }
        Insert: {
          device_id: string
          id?: number
          is_simulated?: boolean
          metric: string
          received_at?: string
          recorded_at: string
          source?: string
          value: number
        }
        Update: {
          device_id?: string
          id?: number
          is_simulated?: boolean
          metric?: string
          received_at?: string
          recorded_at?: string
          source?: string
          value?: number
        }
        Relationships: [
          {
            foreignKeyName: "sensor_readings_device_id_fkey"
            columns: ["device_id"]
            isOneToOne: false
            referencedRelation: "iot_devices"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      volunteers: {
        Row: {
          created_at: string
          is_available: boolean
          organization_id: string | null
          phone: string | null
          service_area: string | null
          updated_at: string
          user_id: string
          vehicle_type: string
          verification_status: Database["public"]["Enums"]["verification_status"]
        }
        Insert: {
          created_at?: string
          is_available?: boolean
          organization_id?: string | null
          phone?: string | null
          service_area?: string | null
          updated_at?: string
          user_id: string
          vehicle_type?: string
          verification_status?: Database["public"]["Enums"]["verification_status"]
        }
        Update: {
          created_at?: string
          is_available?: boolean
          organization_id?: string | null
          phone?: string | null
          service_area?: string | null
          updated_at?: string
          user_id?: string
          vehicle_type?: string
          verification_status?: Database["public"]["Enums"]["verification_status"]
        }
        Relationships: [
          {
            foreignKeyName: "volunteers_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_access_match: {
        Args: { _match: string; _user_id: string }
        Returns: boolean
      }
      expire_stale_donations: { Args: never; Returns: number }
      get_impact_stats: { Args: never; Returns: Json }
      has_any_role: {
        Args: {
          _roles: Database["public"]["Enums"]["app_role"][]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_donation_owner: {
        Args: { _donation: string; _user_id: string }
        Returns: boolean
      }
      is_org_admin: {
        Args: { _org: string; _user_id: string }
        Returns: boolean
      }
      is_org_member: {
        Args: { _org: string; _user_id: string }
        Returns: boolean
      }
      is_verified_recipient_member: {
        Args: { _user_id: string }
        Returns: boolean
      }
      is_volunteer_for_donation: {
        Args: { _donation: string; _user_id: string }
        Returns: boolean
      }
      is_volunteer_for_match: {
        Args: { _match: string; _user_id: string }
        Returns: boolean
      }
      list_verified_organizations: {
        Args: never
        Returns: {
          id: string
          is_recipient: boolean
          name: string
          org_type: Database["public"]["Enums"]["org_type"]
        }[]
      }
      org_visible_via_match: {
        Args: { _org: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      alert_status: "active" | "resolved"
      app_role:
        | "super_admin"
        | "municipal_authority"
        | "disaster_officer"
        | "iot_operator"
        | "ngo_admin"
        | "food_donor"
        | "recipient_org"
        | "volunteer"
        | "public_user"
      delivery_status: "assigned" | "picked_up" | "delivered" | "cancelled"
      device_type:
        | "water_level"
        | "rain_gauge"
        | "soil_moisture"
        | "weather_station"
        | "gateway"
        | "gps"
      donation_status:
        | "posted"
        | "safety_review"
        | "verified"
        | "matched"
        | "accepted"
        | "pickup_assigned"
        | "collected"
        | "delivered"
        | "completed"
        | "cancelled"
        | "rejected"
        | "expired"
      food_category:
        | "cooked_meal"
        | "rice_grains"
        | "bread_roti"
        | "curry_dal"
        | "sweets_dessert"
        | "fruits_vegetables"
        | "packaged"
        | "beverages"
        | "other"
      match_status:
        | "proposed"
        | "accepted"
        | "rejected"
        | "pickup_assigned"
        | "collected"
        | "delivered"
        | "completed"
        | "cancelled"
      member_status: "pending" | "approved" | "rejected"
      org_type:
        | "ngo"
        | "food_bank"
        | "night_shelter"
        | "orphanage"
        | "old_age_home"
        | "community_kitchen"
        | "hospital_welfare"
        | "outreach"
        | "catering"
        | "hotel"
        | "restaurant"
        | "banquet_hall"
        | "religious"
        | "event_organizer"
        | "corporate"
        | "municipal"
        | "other"
      packaging_condition:
        | "sealed"
        | "covered_containers"
        | "open_trays"
        | "damaged"
      risk_level: "normal" | "watch" | "alert" | "severe" | "emergency"
      storage_condition:
        | "hot_held"
        | "refrigerated"
        | "room_temperature"
        | "frozen"
      verification_status: "pending" | "verified" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      alert_status: ["active", "resolved"],
      app_role: [
        "super_admin",
        "municipal_authority",
        "disaster_officer",
        "iot_operator",
        "ngo_admin",
        "food_donor",
        "recipient_org",
        "volunteer",
        "public_user",
      ],
      delivery_status: ["assigned", "picked_up", "delivered", "cancelled"],
      device_type: [
        "water_level",
        "rain_gauge",
        "soil_moisture",
        "weather_station",
        "gateway",
        "gps",
      ],
      donation_status: [
        "posted",
        "safety_review",
        "verified",
        "matched",
        "accepted",
        "pickup_assigned",
        "collected",
        "delivered",
        "completed",
        "cancelled",
        "rejected",
        "expired",
      ],
      food_category: [
        "cooked_meal",
        "rice_grains",
        "bread_roti",
        "curry_dal",
        "sweets_dessert",
        "fruits_vegetables",
        "packaged",
        "beverages",
        "other",
      ],
      match_status: [
        "proposed",
        "accepted",
        "rejected",
        "pickup_assigned",
        "collected",
        "delivered",
        "completed",
        "cancelled",
      ],
      member_status: ["pending", "approved", "rejected"],
      org_type: [
        "ngo",
        "food_bank",
        "night_shelter",
        "orphanage",
        "old_age_home",
        "community_kitchen",
        "hospital_welfare",
        "outreach",
        "catering",
        "hotel",
        "restaurant",
        "banquet_hall",
        "religious",
        "event_organizer",
        "corporate",
        "municipal",
        "other",
      ],
      packaging_condition: [
        "sealed",
        "covered_containers",
        "open_trays",
        "damaged",
      ],
      risk_level: ["normal", "watch", "alert", "severe", "emergency"],
      storage_condition: [
        "hot_held",
        "refrigerated",
        "room_temperature",
        "frozen",
      ],
      verification_status: ["pending", "verified", "rejected"],
    },
  },
} as const
