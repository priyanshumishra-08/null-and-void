import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import hero from "@/assets/hero-ganga.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JAL-RAKSHAK — Flood early warning & food rescue, Patna" },
      { name: "description", content: "Flood intelligence for the Ganga Basin and ANN-SETU surplus food rescue for Patna, Bihar." },
      { property: "og:title", content: "JAL-RAKSHAK" },
      { property: "og:description", content: "Protecting Lives. Rescuing Food. Building a Climate-Resilient Ganga Basin." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-navy text-navy-foreground">
      <img src={hero} alt="The Ganga at Patna under monsoon clouds" className="absolute inset-0 h-full w-full object-cover" />
      <div className="hero-overlay absolute inset-0" />
      <div className="relative mx-auto flex min-h-screen max-w-5xl flex-col justify-end px-6 pb-20">
        <p className="eyebrow text-teal">Ganga Basin · Patna, Bihar · SDG 13</p>
        <h1 className="mt-3 text-5xl font-semibold md:text-7xl">JAL-RAKSHAK</h1>
        <p className="mt-4 max-w-2xl text-lg opacity-90">Protecting Lives. Rescuing Food. Building a Climate-Resilient Ganga Basin.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button asChild variant="hero" size="xl"><Link to="/auth" search={{ redirect: undefined }}>Join the network</Link></Button>
          <Button asChild variant="heroOutline" size="xl"><Link to="/dashboard">Open dashboard</Link></Button>
        </div>
      </div>
    </section>
  );
}
