import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useMyRoles, useSession } from "@/hooks/use-auth";
import { ROLE_LABELS } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — JAL-RAKSHAK" }, { name: "description", content: "Your JAL-RAKSHAK dashboard." }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = useSession();
  const { data: roles } = useMyRoles(user?.id);
  const qc = useQueryClient();
  const navigate = useNavigate();
  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: { redirect: undefined }, replace: true });
  }
  return (
    <div className="mx-auto max-w-3xl space-y-6 p-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Welcome{user?.email ? `, ${user.email}` : ""}</h1>
        <Button variant="outline" onClick={signOut}>Sign out</Button>
      </div>
      <div className="card-elevated p-6">
        <p className="eyebrow text-muted-foreground">Your roles</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {(roles ?? []).map((r) => <span key={r} className="rounded-md bg-secondary px-2 py-1 text-sm">{ROLE_LABELS[r]}</span>)}
        </div>
      </div>
    </div>
  );
}
