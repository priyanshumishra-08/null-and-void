import { describe, expect, it } from "vitest";
import { screenFood } from "@/lib/food-safety";
import { evaluateRecipient, planMatches, type RecipientForMatch } from "@/lib/matching";

const now = new Date("2026-11-20T20:00:00+05:30");
const hoursAgo = (h: number) => new Date(now.getTime() - h * 3_600_000);
const inHours = (h: number) => new Date(now.getTime() + h * 3_600_000);

describe("food safety screening", () => {
  it("rejects cooked rice kept at room temperature for more than 2 hours", () => {
    const s = screenFood({ category: "rice_grains", storage: "room_temperature", packaging: "covered_containers", preparedAt: hoursAgo(2.5), collectionDeadline: inHours(3) }, now);
    expect(s.result).toBe("fail");
  });

  it("passes hot-held food above 60°C prepared 1 hour ago with a 4-hour window", () => {
    const s = screenFood({ category: "curry_dal", storage: "hot_held", temperatureC: 68, packaging: "covered_containers", preparedAt: hoursAgo(1), collectionDeadline: inHours(6) }, now);
    expect(s.result).toBe("pass");
    expect(s.maxSafeUntil).toBe(inHours(3).toISOString());
  });

  it("treats 'hot held' food measured below 60°C as room temperature", () => {
    const s = screenFood({ category: "cooked_meal", storage: "hot_held", temperatureC: 45, packaging: "covered_containers", preparedAt: hoursAgo(2.2), collectionDeadline: inHours(3) }, now);
    expect(s.effectiveStorage).toBe("room_temperature");
    expect(s.result).toBe("fail");
  });

  it("always rejects damaged packaging", () => {
    const s = screenFood({ category: "packaged", storage: "room_temperature", packaging: "damaged", preparedAt: hoursAgo(0.5), collectionDeadline: inHours(5) }, now);
    expect(s.result).toBe("fail");
  });

  it("caps the safe deadline at the donor's collection deadline", () => {
    const s = screenFood({ category: "cooked_meal", storage: "refrigerated", temperatureC: 4, packaging: "sealed", preparedAt: hoursAgo(1), collectionDeadline: inHours(2) }, now);
    expect(s.maxSafeUntil).toBe(inHours(2).toISOString());
  });

  it("rejects food with less than 30 minutes of safe time left", () => {
    const s = screenFood({ category: "cooked_meal", storage: "room_temperature", packaging: "covered_containers", preparedAt: hoursAgo(1.6), collectionDeadline: inHours(4) }, now);
    expect(s.result).toBe("fail");
  });
});

const base = { latitude: 25.61, longitude: 85.14, remainingKg: 120, isVegetarian: true, allergens: [] as string[], safeUntil: inHours(3) };
const org = (o: Partial<RecipientForMatch>): RecipientForMatch => ({ id: "o", name: "Org", latitude: 25.62, longitude: 85.15, capacityKg: 100, currentLoadKg: 0, vegetarianOnly: false, allergenExclusions: [], availableVolunteers: 1, ...o });

describe("matching engine", () => {
  it("excludes vegetarian-only recipients for non-vegetarian food", () => {
    const r = evaluateRecipient({ ...base, isVegetarian: false }, org({ vegetarianOnly: true }), 15, now);
    expect(r.ok).toBe(false);
  });

  it("excludes recipients with an allergen conflict", () => {
    const r = evaluateRecipient({ ...base, allergens: ["peanuts"] }, org({ allergenExclusions: ["Peanuts"] }), 15, now);
    expect(r.ok).toBe(false);
  });

  it("excludes recipients beyond the matching radius", () => {
    const r = evaluateRecipient(base, org({ latitude: 25.9, longitude: 85.6 }), 15, now);
    expect(r.ok).toBe(false);
  });

  it("splits a 120 kg donation across recipients by available capacity", () => {
    const plan = planMatches(base, [org({ id: "a", capacityKg: 80 }), org({ id: "b", capacityKg: 100, latitude: 25.63 })], { radiusKm: 15, maxMatches: 5 }, now);
    const total = plan.allocations.reduce((s, a) => s + a.suggestedKg, 0);
    expect(total).toBe(120);
    expect(plan.allocations.length).toBe(2);
  });
});
